from setuptools import setup

setup(
  name="homework_exercise",
  version="1.0.0",
  scripts=["some_calculation_function"]
)